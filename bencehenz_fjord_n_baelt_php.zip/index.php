<?php include ("partials/header.php"); ?>
	<div class="main-content">
		<div class="row">
			<div class="column two-thirds"> <img class="balloons" src="assets/img/balloons.png" alt="balloons" height="100" width="100"></img>
				<p>Come and celebrate with us our <b>20th</b> Birthday! Enjor our <b>20%</b> discounts for all of our avaiable tickets.</p>
				<p>Furthermore, kids will enjoy this experience much more through our new game!</p> <img class="thing" src="assets/img/thingie.png" alt="thing"></img>
			</div>
			<div class="column one-third"><img width="200" height="215" src="assets/img/FB_20_icon.png" alt="Fjord and Baelt 20th logo"></img><img src="assets/img/confetti.png" alt="confetti"></img>
				<p>You will find more information by clicking<a href="http://www.fjordbaelt.dk/" target="_blank" title="Fjord&Bælt"> here!</a></p>
			</div>
		</div>
	</div>
	<?php include ("partials/footer.php"); ?>