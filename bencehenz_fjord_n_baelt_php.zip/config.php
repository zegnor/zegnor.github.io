<?php phpinfo();
?>