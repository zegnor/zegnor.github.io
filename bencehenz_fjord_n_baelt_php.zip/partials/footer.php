<footer class="main-footer">
	<div class="row">
		<div class="ftimg"></div> &copy; 2017 Group 13. All rights Reserved!
		<div class="handin"><a href="login.php" target="_self" title="hand-in">Hand-in</a></div>
	</div>
</footer>
<script src="assets/js/script.js"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA45esILwprgGJIkE9ECK1FjHBeMcr9OLk&callback=initMap">
</script>
</body>

</html>